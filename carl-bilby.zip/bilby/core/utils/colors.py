class tcolors:
    KEY = '\033[93m'
    VALUE = '\033[91m'
    HIGHLIGHT = '\033[95m'
    END = '\033[0m'
